import { Page } from "@playwright/test";
import BasePage from "./common/Base.page";
import Header from "./Header.page";

class LoginModal extends BasePage {
    private loginModal = 'xpath=//gg-login-modal/..';
    private usernameInput = 'xpath=//input[@id="inputUsername"]';
    private passwordInput = 'xpath=//input[@id="inputPassword"]';
    private signInButton = 'xpath=//button[@class="btn btn-lg btn-primary"]';

    constructor(page: Page) {
        super(page);
    };

    async isLoginModalVisible() {
        await this.elementToBeVisible(await this.getElement(this.loginModal));
        return this;
    }

    async setUsername(username: string) {
        const usernameLocator = await this.getElement(this.usernameInput)
        await this.fillElement(usernameLocator, username);
        return this;
    }

    async setPassword(password: string) {
        const passwordLocator = await this.getElement(this.passwordInput)
        await this.fillElement(passwordLocator, password);
        return this;
    }

    async clickSignInButton() {
        await this.clickElement(await this.getElement(this.signInButton));
        await this.waitForLoad();
        return new Header(this.page);
    }
}

export default LoginModal;