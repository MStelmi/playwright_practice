import { Page } from "@playwright/test";
import BasePage from "./common/Base.page";

class AccountManager extends BasePage {
    private accountManagerHeaderLabel = '//h1[text()="Account Manager"]';
    private editContactDetailsLink = 'xpath=//a[text()="Edit Contact Details"]';

    constructor(page: Page) {
        super(page);
    }

    async waitAccountManagerToBeLoaded() {
        await this.waitForLoad();
        await this.elementToBeVisible(await this.getElement(this.accountManagerHeaderLabel));
        return this;
    }

    async goToEditContactDetails() {
        await this.clickElement(await this.getElement(this.editContactDetailsLink));
        return this;
    }
}

export default AccountManager;