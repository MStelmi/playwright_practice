import { Locator, Page } from "@playwright/test";
import { getElementByText } from "../utils/listElementHelper";
import BasePage from "./common/Base.page";
import UserOptions from "../enums/UserOptionsEnum";

class ProfileModal extends BasePage {
    private profileModalContainer = 'xpath=//div[@class="dropdown-menu container-fluid show"]';
    private availableProfileOptions = 'xpath=//a[@class="dropdown-item"]';

    constructor(page: Page) {
        super(page);
    };

    public async navigateToAccountManager() {
        await this.clickProfileOption(UserOptions.Account);
        return this;
    }

    public async waitForProfileModalContainer() {
        await this.elementToBeVisible(await this.getProfileModalContainer());
        return this;
    }

    private async clickProfileOption(optionText: string) {
        const optionsLocator = await this.getElementFromParent(await this.getProfileModalContainer(), this.availableProfileOptions);
        await this.clickElement(await getElementByText(this.page, optionsLocator, optionText))
    }

    private async getProfileModalContainer(): Promise<Locator> {
        return this.getElement(this.profileModalContainer);
    }
}

export default ProfileModal;