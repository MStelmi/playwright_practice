import { Locator, Page, expect } from "@playwright/test";
import BasePage from "./common/Base.page";
import LoginModal from "./LoginModal.page";

class Header extends BasePage {
    private signInButton = 'xpath=//a[@ggloginbutton and text()="Sign In"]';
    private loggedUserName = 'xpath=//li[@class="d-c-nav-user tw-hidden md:tw-inline-block"]//gg-my-geek//span[@class="mygeek-dropdown-username tw-truncate"]';

    constructor(page: Page) {
        super(page);
    };

    async clickSignInButton() {
        await this.clickElement(await this.getElement(this.signInButton));
        await this.waitForLoad();
        return new LoginModal(this.page).isLoginModalVisible();
    }

    async isUserLogged(username: string) {
        await expect(await this.getLoggedUserNameLocator()).toHaveText(username);
        return this;
    }

    async clickLoggedUserName() {
        await this.clickElement(await this.getLoggedUserNameLocator());
        return this;
    }

    private async getLoggedUserNameLocator(): Promise<Locator> {
        return this.getElement(this.loggedUserName);
    }
}

export default Header;