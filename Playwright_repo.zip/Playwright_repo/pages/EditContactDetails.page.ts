import { Page } from "@playwright/test";
import BasePage from "./common/Base.page";

class EditContactDetails extends BasePage {
    private firstNameInput = '//input[@name="firstname"]';
    private cityinput = '//input[@name="city"]';
    private countryDropdown = '//select[@name="country"]';

    constructor(page: Page) {
        super(page);
    }

    async waitForPageToBeDisplayed() {
        await this.elementToBeVisible(await this.getElement(this.firstNameInput));
        return this;
    }

    async setFirstNameInput(firstName: string) {
        const firstNameLocator = await this.getElement(this.firstNameInput)
        await this.fillElement(firstNameLocator, firstName);
        return this;
    }

    async setCityInput(city: string) {
        const cityLocator = await this.getElement(this.cityinput)
        await this.fillElement(cityLocator, city);
        return this;
    }

    async selectCountryDropdown(country: string) {
        const countryLocator = await this.getElement(this.countryDropdown)
        await this.selectElementOption(countryLocator, country);
        return this;
    }
}

export default EditContactDetails;