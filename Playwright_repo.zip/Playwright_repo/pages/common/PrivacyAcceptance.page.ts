import { Page } from '@playwright/test';
import BasePage from './Base.page';

class PrivacyAcceptancePage extends BasePage {
    private rejectAllButton = 'xpath=//div[@class="fc-footer-buttons-container"]//button[@aria-label="Reject All"]';

    constructor(page: Page) {
        super(page);
    };

    async clickRejectAllButton() {
        const rejectAllButton = await this.getElement(this.rejectAllButton);
        await this.elementToBeVisible(rejectAllButton);
        await this.clickElement(rejectAllButton);
        await this.elementToBeHidden(rejectAllButton);
        await this.waitForLoad();
    }
}

export default PrivacyAcceptancePage;