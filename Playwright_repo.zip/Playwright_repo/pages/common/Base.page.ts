import { Locator, Page } from 'playwright';
import { expect } from 'playwright/test';

class BasePage {
    page: Page;

    constructor(page: Page) {
        this.page = page;
    }

    protected async getElement(xpath: string): Promise<Locator> {
        return this.page.locator(xpath);
    }

    protected async getElementFromParent(parent: Locator, childElementsXpath: string): Promise<Locator> {
        return parent.locator(childElementsXpath);
    }

    protected async clickElement(locator: Locator) {
        await locator.click();
    }

    protected async fillElement(locator: Locator, value: string) {
        await locator.fill(value);
    }

    protected async selectElementOption(locator: Locator, value: string) {
        await locator.selectOption(value);
    }

    protected async elementToBeVisible(locator: Locator) {
        await expect(locator).toBeVisible();
    }

    protected async elementToBeHidden(locator: Locator) {
        await expect(locator).toBeHidden();
    }

    protected async waitForLoad() {
        await this.page.waitForLoadState();
    }

    protected async goTo(url: string) {
        await this.page.goto(url);
        await this.waitForLoad();
    }
}

export default BasePage;