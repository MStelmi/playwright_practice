export const closeSession = false;
export const reuseLastUrl = false;
