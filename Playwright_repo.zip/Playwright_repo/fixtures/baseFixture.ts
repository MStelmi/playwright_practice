import { Page, test as baseTest } from "@playwright/test";
import fs from 'fs/promises';
import { reuseLastUrl } from "../browser";

const sessionFilePath = 'sessionData.json';
const lastUrlFilePath = 'lastSessionUrl.txt';
const codingType = 'utf8';

export interface BaseFixtures {
    page: Page;
}

export function createPageInstance<T>(Class: new (page: Page) => T) {
    return async ({ page }: { page: Page }, use: (instance: T) => Promise<void>) => {
        const instance = new Class(page);
        await use(instance);
    };
}

async function saveSessionData(page: Page) {
    const storageState = await page.context().storageState();
    await fs.writeFile(sessionFilePath, JSON.stringify(storageState), codingType);
    console.log('Session data saved:', storageState);
}

async function saveUrl(page: Page) {
    try {
        const url = page.url();
        await fs.writeFile(lastUrlFilePath, url);
        console.log('Current URL saved:', url);
    } catch (error) {
        console.error('Error saving URL:', error);
    }
}

export async function navigateToLastUrlIfNeeded(page: Page) {
    try {
        if (reuseLastUrl) {
            const data = await fs.readFile(lastUrlFilePath, codingType);
            const url = data.toString().trim(); // Odczytujemy URL z pliku tekstowego
            console.log("plik z ostatniego reuzywanego url:", url)
            if (url) {
                await page.goto(url); // Przejdz do poprzedniego URL-a jeśli istnieje
            }
        }
    } catch (error) {
        console.error('Error reading or navigating to last URL:', error);
    }
}

const test = baseTest.extend<BaseFixtures>({
    page: async ({ context }, use) => {
        const page = await context.newPage();
        await use(page);
    }
});

test.beforeEach(async ({ page }) => {
    //await navigateToLastUrlIfNeeded(page);
});

test.afterEach(async ({ page }) => {
    await saveUrl(page);
    await saveSessionData(page);
});

export { test };