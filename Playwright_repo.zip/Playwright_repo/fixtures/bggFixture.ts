import { test as baseTest } from "@playwright/test";
import { BaseFixtures, createPageInstance } from "./baseFixture";
import Header from "../pages/Header.page";
import ProfileModal from "../pages/ProfileModal.page";
import BggStepdefs from "../stepdefs/BggStepdefs";
import AccountManager from "../pages/AccountManager.page";
import EditContactDetails from "../pages/EditContactDetails.page";

interface BggFixtures extends BaseFixtures {
    header: Header;
    profileModal: ProfileModal;
    bggStepdefs: BggStepdefs;
    accountManager: AccountManager;
    editContactDetails: EditContactDetails;
}

const test = baseTest.extend<BggFixtures>({
    header: createPageInstance(Header),
    profileModal: createPageInstance(ProfileModal),
    bggStepdefs: createPageInstance(BggStepdefs),
    accountManager: createPageInstance(AccountManager),
    editContactDetails: createPageInstance(EditContactDetails)
});

export { test };