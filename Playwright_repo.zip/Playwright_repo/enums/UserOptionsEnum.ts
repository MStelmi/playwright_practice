enum UserOptions {
    Profile = "Profile",
    FanItems = "Fan Items",
    SignOut = "Sign Out",
    Account = "Account",
    Wishlist = "Wishlist"

}
export default UserOptions;