import { Page } from "@playwright/test";
import BasePage from "../pages/common/Base.page";
import PrivacyAcceptancePage from "../pages/common/PrivacyAcceptance.page";
import Header from "../pages/Header.page";
import LoginModal from "../pages/LoginModal.page";

class BggStepdefs extends BasePage {

  constructor(page: Page) {
    super(page)
  }

  async openAndLoginToBgg(url: string, username: string, password: string) {
    await this.openApplication(url);
    await this.loginToApplication(username, password);
  }

  async openApplication(url: string) {
    await this.goTo(url);
    await new PrivacyAcceptancePage(this.page).clickRejectAllButton();
    return this;
  }

  async loginToApplication(username: string, password: string) {
    new Header(this.page).clickSignInButton();
    const loginModal = new LoginModal(this.page);
    await loginModal.setUsername(username);
    await loginModal.setPassword(password);
    await loginModal.clickSignInButton();
    await new Header(this.page).isUserLogged(username);
  }
}

export default BggStepdefs;