import { test } from "../fixtures/bggFixture";
import * as credentials from "../testdata/bgg.json";
import {faker } from '@faker-js/faker';

test('verify user is able to edit profile settings', async ({ bggStepdefs, header, profileModal, accountManager, editContactDetails }) => {
  await bggStepdefs.openAndLoginToBgg(credentials.url, credentials.username, credentials.password);
  await header.clickLoggedUserName();
  await profileModal.waitForProfileModalContainer();
  await profileModal.navigateToAccountManager();
  await accountManager.waitAccountManagerToBeLoaded();
  await accountManager.goToEditContactDetails();
  await editContactDetails.waitForPageToBeDisplayed();
  await editContactDetails.setFirstNameInput(faker.animal.bear());
});