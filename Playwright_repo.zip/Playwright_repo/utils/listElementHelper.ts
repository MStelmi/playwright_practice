import { Locator, Page } from '@playwright/test';

export async function getElementByText(page: Page, containerLocator: Locator, optionText: string): Promise<Locator> {
    return containerLocator.locator(`text=${optionText}`);
}